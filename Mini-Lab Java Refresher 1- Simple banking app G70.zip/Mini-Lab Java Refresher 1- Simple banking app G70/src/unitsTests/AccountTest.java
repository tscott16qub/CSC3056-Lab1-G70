package unitsTests;

import java.util.Date;

import model.Account;

public class AccountTest {
Account testaccount = new Account ("60604578", "M-Smith", "Student Account", 2025-02-05);
	System.out.println(testaccount);
}
