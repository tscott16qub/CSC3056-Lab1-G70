package tests;

import model.User;
public class UserTests {

	public static void main(String[] args) {
		

	}

}
